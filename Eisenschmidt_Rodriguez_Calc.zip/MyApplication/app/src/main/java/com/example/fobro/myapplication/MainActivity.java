package com.example.fobro.myapplication;

import android.content.Intent;
import android.net.wifi.p2p.WifiP2pManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Scanner;
import java.util.Stack;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    public Button buttonAdd, buttonSub, buttonMulti, buttonDiv, buttonSqrt, buttonPow, buttonClr;
    private EditText operand1, operand2;
    private TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    public void init(){

        buttonAdd = findViewById(R.id.btnAdd);
        buttonSub= findViewById(R.id.btnSub);
        buttonMulti = findViewById(R.id.btnMulti);
        buttonDiv = findViewById(R.id.btnDiv);
        buttonSqrt= findViewById(R.id.btnSqrt);
        buttonPow = findViewById(R.id.btnPow);
        buttonClr = findViewById(R.id.btnClear);
        operand1 = findViewById(R.id.operand1);
        operand2 = findViewById(R.id.operand2);
        result = findViewById(R.id.result);

        buttonAdd.setOnClickListener(this);
        buttonSub.setOnClickListener(this);
        buttonMulti.setOnClickListener(this);
        buttonDiv.setOnClickListener(this);
        buttonSqrt.setOnClickListener(this);
        buttonPow.setOnClickListener(this);
        buttonClr.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        String op1 = operand1.getText().toString();
        String op2 = operand2.getText().toString();
        switch (view.getId()){
            case R.id.btnAdd:
                //double res = Double.parseDouble(op1) + Double.parseDouble(op2);
                result.setText(String.valueOf(add(op1, op2)));
                break;
            case R.id.btnSub:
                //res = Double.parseDouble(op1) - Double.parseDouble(op2);
                result.setText(String.valueOf(subtract(op1, op2)));
                break;
            case R.id.btnMulti:
                //res = Double.parseDouble(op1) * Double.parseDouble(op2);
                result.setText(String.valueOf(multiply(op1, op2)));
                break;
            case R.id.btnDiv:
                //res = Double.parseDouble(op1) / Double.parseDouble(op2);
                result.setText(String.valueOf(divide(op1, op2)));
                break;
            case R.id.btnSqrt:
                double res = Math.sqrt(Double.parseDouble(op1));
                result.setText(String.valueOf(res));
                break;
            case R.id.btnPow:
                res = Math.pow(Double.parseDouble(op1), Double.parseDouble(op2));
                result.setText(String.valueOf(res));
                break;
            case R.id.btnClear:
                result.setText(" ");
                operand1.setText(" ");
                operand2.setText(" ");
                break;
        }
    }


    private Stack<Character> stack = new Stack<Character>();

    public String PostfixConverter(String infixExpression) {
        String expression = infixExpression;
        String postfixString = "";
        for (int index = 0; index < expression.length(); ++index) {
            char value = expression.charAt(index);
            if (value == '(') {

            } else if (value == ')') {
                Character oper = stack.peek();

                while (!(oper.equals('(')) && !(stack.isEmpty())) {
                    stack.pop();
                    postfixString += oper.charValue();

                }
            } else if (value == '+' || value == '-') {
                if (stack.isEmpty()) {
                    stack.push(value);
                } else {
                    Character oper = stack.peek();
                    while (!(stack.isEmpty() || oper.equals(('(')) || oper.equals((')')))) {
                        stack.pop();
                        postfixString += oper.charValue();
                    }
                    stack.push(value);
                }
            } else if (value == '*' || value == '/') {
                if (stack.isEmpty()) {
                    stack.push(value);
                } else {
                    Character oper = stack.peek();
                    while (!oper.equals(('+')) && !oper.equals(('-')) && !stack.isEmpty()) {
                        stack.pop();
                        postfixString += oper.charValue();
                    }
                    stack.push(value);
                }
            } else {
                postfixString += value;
            }
        }

        while (!stack.isEmpty()) {
            Character oper = stack.peek();
            if (!oper.equals(('('))) {
                stack.pop();
                postfixString += oper.charValue();
            }
        }
        return postfixString;
    }

    public static double postfixEvaluate(String exp) {
        Stack<Integer> s = new Stack<Integer> ();
        Scanner tokens = new Scanner(exp);

        while (tokens.hasNext()) {
            if (tokens.hasNextInt()) {
                s.push(tokens.nextInt());
            } else {
                int num2 = s.pop();
                int num1 = s.pop();
                String op = tokens.next();

                if (op.equals("+")) {
                    s.push(num1 + num2);
                } else if (op.equals("-")) {
                    s.push(num1 - num2);
                } else if (op.equals("*")) {
                    s.push(num1 * num2);
                } else {
                    s.push(num1 / num2);
                }

                //  "+", "-", "*", "/"
            }
        }
        return s.pop();
    }

    public double add(String op1, String op2){
        double first, second;
        String operand1 = PostfixConverter(op1);
        String operand2 = PostfixConverter(op2);
        first = postfixEvaluate(operand1);
        second = postfixEvaluate(operand2);
        return first + second;
    }

    public double subtract(String op1, String op2){
        double first, second;
        String operand1 = PostfixConverter(op1);
        String operand2 = PostfixConverter(op2);
        first = postfixEvaluate(operand1);
        second = postfixEvaluate(operand2);
        return first - second;
    }

    public double multiply(String op1, String op2){
        double first, second;
        String operand1 = PostfixConverter(op1);
        String operand2 = PostfixConverter(op2);
        first = postfixEvaluate(operand1);
        second = postfixEvaluate(operand2);
        return first * second;
    }

    public double divide(String op1, String op2){
        double first, second;
        String operand1 = PostfixConverter(op1);
        String operand2 = PostfixConverter(op2);
        first = postfixEvaluate(operand1);
        second = postfixEvaluate(operand2);
        return first / second;
    }


}
